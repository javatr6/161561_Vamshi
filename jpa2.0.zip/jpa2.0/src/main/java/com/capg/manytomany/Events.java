package com.capg.manytomany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Events {

	@Id
	private String eventId;
	private String eventName;
	private LocalDate eventDate;
	
	@ManyToMany
	@JoinTable(name="event_delegates",joinColumns= {@JoinColumn(name="events")},inverseJoinColumns= {@JoinColumn(name="delegates")})
	private List<Delegates> delegates=new ArrayList<>();

	
	public Events() {
		
	}
	public Events(String eventId, String eventName, List<Delegates> delegates) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.delegates = delegates;
	}

	public LocalDate getEventDate() {
		return eventDate;
	}
	public void setEventDate(LocalDate eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public List<Delegates> getDelegates() {
		return delegates;
	}

	public void setDelegates(List<Delegates> delegates) {
		this.delegates = delegates;
	}

	@Override
	public String toString() {
		return "Events [eventId=" + eventId + ", eventName=" + eventName + ", delegates=" + delegates + "]";
	}
	
	
}
