package com.capg.inheritance;

import java.time.LocalDate;

import javax.persistence.Entity;

@Entity
public class Task extends Module {

	private String taskName;
	private LocalDate taskEndDate;
	
	public Task() {
		
	}
	public Task(String taskName) {
		super();
		this.taskName = taskName;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	
	

	public LocalDate getTaskEndDate() {
		return taskEndDate;
	}
	public void setTaskEndDate(LocalDate taskEndDate) {
		this.taskEndDate = taskEndDate;
	}
	@Override
	public String toString() {
		return "Task [taskName=" + taskName + "]";
	}
	
}
