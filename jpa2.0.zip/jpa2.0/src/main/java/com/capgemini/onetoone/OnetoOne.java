package com.capgemini.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class OnetoOne {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		
		Customer customer=new Customer("manoj","ayyapu",28800.0);
		Address address=new Address(101,"Hyderabad",customer);
		
		Customer customer1=new Customer("Vignesh","Mitta",15500.0);
		Address address1=new Address(1010,"Chennai",customer1);
		
		entityManager.persist(customer);
		entityManager.persist(address);
		entityManager.persist(customer1);
		entityManager.persist(address1);
		
		entityTransaction.commit();
		entityManager.close();

	}

}
