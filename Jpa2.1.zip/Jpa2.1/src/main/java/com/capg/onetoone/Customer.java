package com.capg.onetoone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Customer {

	@Id
	@GeneratedValue
	private int custId;
	private String firstName;
	private String lastName;
	private Double regFee;
	
	@OneToOne
	@JoinColumn(name="Addfk")
	private Address address;

	public Customer() {
		
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getRegFee() {
		return regFee;
	}
	public void setRegFee(Double regFee) {
		this.regFee = regFee;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Customer(int custId, String firstName, String lastName, Double regFee, Address address) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
		this.address = address;
	}
	
	public Customer(String firstName, String lastName, Double regFee) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", regFee="
				+ regFee + ", address=" + address + "]";
	}

	
}
