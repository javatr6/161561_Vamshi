package com.capg.onetomany;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {

	@Id
	private int employeeId;
	private String employeeName;
	private LocalDate hiringDate;
	
	@ManyToOne
	@JoinColumn(name="CompanyFk")
	private Company company;
	
	

	public Employee(int employeeId, String employeeName, Company company) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.company = company;
	}

	

	public LocalDate getHiringDate() {
		return hiringDate;
	}



	public void setHiringDate(LocalDate hiringDate) {
		this.hiringDate = hiringDate;
	}



	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	
}
